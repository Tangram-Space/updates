#!/usr/bin/env python3
"""Local SigLIP worker for Media Atlas. It never uses the network."""
import base64
import hashlib
import json
import os
import sys

MODEL = os.environ["MEDIA_ATLAS_SIGLIP_MODEL"]
_bundle = None


def emit(value):
    print(json.dumps(value, ensure_ascii=False), flush=True)


def model_bundle():
    global _bundle
    if _bundle is not None:
        return _bundle
    import torch
    from transformers import AutoModel, AutoProcessor
    processor = AutoProcessor.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False)
    model = AutoModel.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False)
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    try:
        model = model.to(device)
    except Exception:
        device = "cpu"
        model = model.to(device)
    model.eval()
    _bundle = (torch, processor, model, device)
    return _bundle


def normalized_vector(value):
    import numpy as np
    if hasattr(value, "pooler_output"):
        value = value.pooler_output
    if isinstance(value, tuple):
        value = value[1]
    vector = value.detach().float().cpu().numpy().reshape(-1).astype("<f4")
    norm = float(np.linalg.norm(vector))
    if not norm:
        raise ValueError("Embedding vacío")
    return vector / norm


def encode(vector):
    return base64.b64encode(vector.astype("<f4").tobytes()).decode("ascii")


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(4 * 1024 * 1024)
            if not chunk:
                return digest.hexdigest()
            digest.update(chunk)


def embed_images(items):
    from PIL import Image, ImageOps
    torch, processor, model, device = model_bundle()
    results = []
    for item in items:
        try:
            before = os.stat(item["path"], follow_symlinks=False)
            if not os.path.isfile(item["path"]) or sha256(item["path"]) != item["sha256"]:
                raise ValueError("El archivo no coincide con su identidad catalogada")
            with Image.open(item["path"]) as source:
                image = ImageOps.exif_transpose(source).convert("RGB")
                inputs = processor(images=image, return_tensors="pt")
            with torch.no_grad():
                output = model.get_image_features(pixel_values=inputs["pixel_values"].to(device))
            after = os.stat(item["path"], follow_symlinks=False)
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError("El archivo cambió durante el análisis")
            vector = normalized_vector(output)
            results.append({"asset_id": item["asset_id"], "dimensions": len(vector), "vector": encode(vector)})
        except Exception as error:
            results.append({"asset_id": item.get("asset_id"), "error": str(error)[:300]})
    return {"results": results}


def embed_text(query):
    torch, processor, model, device = model_bundle()
    prompt = "This is a photo of " + query.strip().rstrip(".") + "."
    inputs = processor(text=[prompt], padding="max_length", return_tensors="pt")
    with torch.no_grad():
        output = model.get_text_features(**{key: value.to(device) for key, value in inputs.items()})
    vector = normalized_vector(output)
    return {
        "dimensions": len(vector), "vector": encode(vector),
        "logit_scale": float(model.logit_scale.exp().item()),
        "logit_bias": float(model.logit_bias.item()),
    }


def execute(request):
    operation = request.get("operation")
    if operation == "embed_images":
        return embed_images(request.get("items", []))
    if operation == "embed_text" and str(request.get("query", "")).strip():
        return embed_text(str(request["query"]))
    raise ValueError("Operación semántica inválida")


def main():
    for line in sys.stdin:
        try:
            emit({"ok": True, **execute(json.loads(line))})
        except Exception as error:
            emit({"ok": False, "error": str(error)[:500]})


if __name__ == "__main__":
    main()
