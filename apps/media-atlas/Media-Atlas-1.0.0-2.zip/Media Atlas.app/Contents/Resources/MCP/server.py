#!/usr/bin/env python3
"""Local Media Atlas MCP server. Private assets and absolute paths never leave it."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from typing import Any


VERSION = "0.1.0"
PROTOCOLS = ("2026-07-28", "2025-11-25", "2025-06-18", "2025-03-26")
MAX_LINE = 1_000_000
DATA = Path(os.environ.get("MEDIA_ATLAS_DATA_DIR", "/Volumes/Dock/Projects/MediaAtlas/Data"))
DATABASE = DATA / "catalog.sqlite"
CLI = Path(os.environ.get("MEDIA_ATLAS_CLI", "/Volumes/Dock/Projects/MediaAtlas/.build/debug/media-atlas"))


def object_schema(properties: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    value: dict[str, Any] = {"type": "object", "properties": properties, "additionalProperties": False}
    if required:
        value["required"] = required
    return value


STRING = {"type": "string"}
LIMIT = {"type": "integer", "minimum": 1, "maximum": 100}
TOOLS = [
    ("catalog_status", "Catalog status", "Counts media visible to local AI. Does not read originals.", object_schema({})),
    ("list_projects", "Projects", "Lists projects and their visible media counts.", object_schema({"limit": LIMIT})),
    ("search_media", "Search media", "Searches stored names, relative paths and OCR text; private media is excluded.", object_schema({"query": STRING, "project_id": STRING, "limit": LIMIT})),
    ("exact_duplicates", "Exact duplicates", "Lists confirmed SHA-256 groups. These are exact identities, not visual suggestions.", object_schema({"limit": LIMIT})),
    ("similarity_suggestions", "Similarity suggestions", "Lists pending image, video and audio suggestions with method and evidence. They are not identities.", object_schema({"limit": LIMIT})),
    ("project_manifest", "Project manifest", "Returns the shared project structure without private media or absolute paths.", object_schema({"project_id": STRING}, ["project_id"])),
    ("request_transfer", "Request transfer", "Prepares an exact copy or move plan for human review in Media Atlas. It never executes the plan.", object_schema({"project_id": STRING, "bin_id": STRING, "action": {"type": "string", "enum": ["copy", "move"]}, "destination": STRING}, ["project_id", "action", "destination"])),
    ("transfer_requests", "Transfer requests", "Lists requested plans and whether a person has approved and run them.", object_schema({"limit": LIMIT})),
    ("ingest_manifest", "Ingest manifest", "Catalogs only the files named by a local manifest. Originals are never moved or modified.", object_schema({"manifest_path": STRING, "depth": {"type": "string", "enum": ["metadata", "identity"]}}, ["manifest_path"])),
    ("analyze_catalog", "Analyze catalog", "Incrementally prepares identities, practical media information, audio, video and image suggestions, and OCR text, reusing valid caches.", object_schema({"kind": {"type": "string", "enum": ["identity", "metadata", "audio", "video", "visual", "text", "identity-and-visual", "all"]}, "limit": {"type": "integer", "minimum": 1, "maximum": 50000}}, ["kind"])),
]

MUTATING = {"request_transfer", "ingest_manifest", "analyze_catalog"}


def tool_definitions() -> list[dict[str, Any]]:
    return [
        {
            "name": name,
            "title": title,
            "description": description,
            "inputSchema": schema,
            "annotations": {"readOnlyHint": name not in MUTATING, "destructiveHint": False, "idempotentHint": name != "request_transfer", "openWorldHint": False},
        }
        for name, title, description, schema in TOOLS
    ]


def connect() -> sqlite3.Connection:
    if not DATABASE.is_file():
        raise ValueError("Media Atlas catalog not found")
    uri = DATABASE.resolve().as_uri() + "?mode=ro"
    database = sqlite3.connect(uri, uri=True, timeout=5)
    database.execute("PRAGMA query_only=ON")
    database.row_factory = sqlite3.Row
    return database


def limit(arguments: dict[str, Any]) -> int:
    value = arguments.get("limit", 25)
    if type(value) is not int or not 1 <= value <= 100:
        raise ValueError("limit must be between 1 and 100")
    return value


def catalog_status(database: sqlite3.Connection, _: dict[str, Any]) -> dict[str, Any]:
    assets = database.execute("SELECT COUNT(*) FROM assets WHERE privacy='local-ai'").fetchone()[0]
    locations = database.execute("SELECT COUNT(*) FROM locations l JOIN assets a ON a.id=l.asset_id WHERE a.privacy='local-ai'").fetchone()[0]
    projects = database.execute("SELECT COUNT(DISTINCT p.id) FROM projects p JOIN project_assets pa ON pa.project_id=p.id JOIN assets a ON a.id=pa.asset_id WHERE p.archived_at IS NULL AND a.privacy='local-ai'").fetchone()[0]
    return {"contract": "media-atlas.mcp-status/1", "assets": assets, "locations": locations, "projects": projects}


def list_projects(database: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    rows = database.execute(
        """SELECT p.id,p.name,p.created_at,COUNT(DISTINCT a.id) AS assets
        FROM projects p LEFT JOIN project_assets pa ON pa.project_id=p.id
        LEFT JOIN assets a ON a.id=pa.asset_id AND a.privacy='local-ai'
        WHERE p.archived_at IS NULL GROUP BY p.id ORDER BY p.name COLLATE NOCASE LIMIT ?""",
        (limit(arguments),),
    )
    return {"contract": "media-atlas.projects/1", "projects": [dict(row) for row in rows]}


def search_media(database: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    query = arguments.get("query", "")
    project = arguments.get("project_id")
    if not isinstance(query, str) or len(query) > 500 or (project is not None and not isinstance(project, str)):
        raise ValueError("invalid search")
    pattern = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    values: list[Any] = [pattern, pattern, pattern]
    project_clause = ""
    if project:
        project_clause = "AND EXISTS(SELECT 1 FROM project_assets pa WHERE pa.asset_id=a.id AND pa.project_id=?)"
        values.append(project)
    values.append(limit(arguments))
    rows = database.execute(
        f"""SELECT a.id,a.sha256,a.byte_size,a.kind,a.format,a.identity_state,l.volume_id,l.relative_path,
        (CASE WHEN l.availability='missing' THEN 'missing' ELSE v.availability END) AS availability
        FROM assets a JOIN locations l ON l.asset_id=a.id JOIN volumes v ON v.id=l.volume_id
        WHERE a.privacy='local-ai' AND (
          l.relative_path LIKE ? ESCAPE '\\' OR a.format LIKE ? ESCAPE '\\' OR
          EXISTS(SELECT 1 FROM analysis_results search_text WHERE search_text.asset_id=a.id AND search_text.method='apple-vision-ocr' AND search_text.result_json LIKE ? ESCAPE '\\')
        ) {project_clause}
        ORDER BY l.relative_path COLLATE NOCASE LIMIT ?""",
        values,
    )
    return {"contract": "media-atlas.search/1", "items": [dict(row) for row in rows]}


def exact_duplicates(database: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    hashes = database.execute(
        """SELECT a.sha256 FROM assets a JOIN locations l ON l.asset_id=a.id
        WHERE a.privacy='local-ai' AND a.sha256 IS NOT NULL GROUP BY a.sha256,a.byte_size HAVING COUNT(l.id)>1
        ORDER BY a.sha256 LIMIT ?""",
        (limit(arguments),),
    )
    groups = []
    for row in hashes:
        items = database.execute(
            """SELECT l.volume_id,l.relative_path,(CASE WHEN l.availability='missing' THEN 'missing' ELSE v.availability END) AS availability
            FROM locations l JOIN assets a ON a.id=l.asset_id JOIN volumes v ON v.id=l.volume_id
            WHERE a.sha256=? AND a.privacy='local-ai' ORDER BY l.volume_id,l.relative_path""",
            (row["sha256"],),
        )
        groups.append({"sha256": row["sha256"], "locations": [dict(item) for item in items]})
    return {"contract": "media-atlas.exact-duplicates/1", "groups": groups}


def similarity_suggestions(database: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    rows = database.execute(
        """SELECT s.id,s.distance,s.method,s.model_version,s.review_state,s.exclusion_reason,
        s.left_asset_id,s.right_asset_id,s.evidence_json,
        (SELECT ll.relative_path FROM locations ll JOIN volumes lv ON lv.id=ll.volume_id WHERE ll.asset_id=s.left_asset_id ORDER BY (ll.availability!='missing' AND lv.availability='online') DESC,ll.relative_path LIMIT 1) AS left_path,
        (SELECT rl.relative_path FROM locations rl JOIN volumes rv ON rv.id=rl.volume_id WHERE rl.asset_id=s.right_asset_id ORDER BY (rl.availability!='missing' AND rv.availability='online') DESC,rl.relative_path LIMIT 1) AS right_path
        FROM similarity_suggestions s
        JOIN assets l ON l.id=s.left_asset_id JOIN assets r ON r.id=s.right_asset_id
        WHERE s.review_state='pending' AND l.privacy='local-ai' AND r.privacy='local-ai'
        ORDER BY s.distance,s.id LIMIT ?""",
        (limit(arguments),),
    )
    suggestions = []
    for row in rows:
        value = dict(row)
        evidence = value.pop("evidence_json", None)
        value["evidence"] = json.loads(evidence) if evidence else None
        suggestions.append(value)
    return {"contract": "media-atlas.similarity-suggestions/1", "suggestions": suggestions}


def project_manifest(_: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    project_id = arguments.get("project_id")
    if not isinstance(project_id, str) or not project_id:
        raise ValueError("project_id is required")
    return run_cli(["project-export", project_id, "--scope", "shared", "--format", "json"])


def request_transfer(_: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    project_id = arguments.get("project_id")
    bin_id = arguments.get("bin_id")
    action = arguments.get("action")
    destination = arguments.get("destination")
    if not isinstance(project_id, str) or not project_id or action not in ("copy", "move") or not isinstance(destination, str) or not destination:
        raise ValueError("invalid transfer request")
    if bin_id is not None and (not isinstance(bin_id, str) or not bin_id):
        raise ValueError("invalid bin")
    command = ["transfer-request", project_id, "--action", action, "--destination", destination]
    if bin_id is not None:
        command.extend(["--bin-id", bin_id])
    return run_cli(command)


def transfer_requests(_: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    result = run_cli(["transfer-requests"])
    requests = result.get("result", [])
    return {"contract": result.get("contract", "media-atlas.transfer-requests/1"), "requests": requests[:limit(arguments)]}


def run_cli(arguments: list[str]) -> dict[str, Any]:
    if not CLI.is_file():
        raise ValueError("Media Atlas CLI not found")
    completed = subprocess.run(
        [str(CLI), "--data", str(DATA), *arguments],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60 * 60,
        check=False,
    )
    if completed.returncode != 0:
        try:
            value = json.loads(completed.stderr)
            raise ValueError(value.get("error", "Media Atlas CLI failed"))
        except json.JSONDecodeError:
            raise ValueError(completed.stderr.strip() or "Media Atlas CLI failed")
    return json.loads(completed.stdout)


def ingest_manifest(_: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    path = arguments.get("manifest_path")
    depth = arguments.get("depth", "metadata")
    if not isinstance(path, str) or not path or depth not in ("metadata", "identity"):
        raise ValueError("invalid manifest request")
    manifest = Path(path)
    if not manifest.is_file() or manifest.suffix.lower() != ".json":
        raise ValueError("manifest not found")
    return run_cli(["ingest-manifest-auto", str(manifest), "--depth", depth])


def analyze_catalog(_: sqlite3.Connection, arguments: dict[str, Any]) -> dict[str, Any]:
    kind = arguments.get("kind")
    value = arguments.get("limit")
    if kind not in ("identity", "metadata", "audio", "video", "visual", "text", "identity-and-visual", "all") or (value is not None and (type(value) is not int or not 1 <= value <= 50000)):
        raise ValueError("invalid analysis request")
    limit_value = value or (5000 if kind == "visual" else 50000)
    results: dict[str, Any] = {"contract": "media-atlas.analysis-request/1", "kind": kind}
    if kind in ("identity", "identity-and-visual", "all"):
        results["identity"] = run_cli(["identity-scan", "--limit", str(limit_value)])
    if kind in ("metadata", "all"):
        results["metadata"] = run_cli(["metadata-scan", "--limit", str(min(limit_value, 20000))])
    if kind in ("audio", "all"):
        results["audio"] = run_cli(["audio-scan", "--limit", str(min(limit_value, 500))])
    if kind in ("video", "all"):
        results["video"] = run_cli(["video-scan", "--limit", str(min(limit_value, 500))])
    if kind in ("visual", "identity-and-visual", "all"):
        results["visual"] = run_cli(["visual-scan", "--limit", str(min(limit_value, 5000))])
    if kind in ("text", "all"):
        results["text"] = run_cli(["text-scan", "--limit", str(min(limit_value, 5000))])
    return results


HANDLERS = {
    "catalog_status": catalog_status,
    "list_projects": list_projects,
    "search_media": search_media,
    "exact_duplicates": exact_duplicates,
    "similarity_suggestions": similarity_suggestions,
    "project_manifest": project_manifest,
    "request_transfer": request_transfer,
    "transfer_requests": transfer_requests,
    "ingest_manifest": ingest_manifest,
    "analyze_catalog": analyze_catalog,
}


def response(request_id: Any, result: Any = None, error: dict[str, Any] | None = None) -> dict[str, Any]:
    value: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
    value["error" if error else "result"] = error if error else result
    return value


def handle(message: dict[str, Any]) -> dict[str, Any] | None:
    method = message.get("method")
    request_id = message.get("id")
    if method and str(method).startswith("notifications/"):
        return None
    if method == "initialize":
        offered = message.get("params", {}).get("protocolVersion")
        selected = offered if offered in PROTOCOLS else PROTOCOLS[1]
        return response(request_id, {"protocolVersion": selected, "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": "media-atlas", "version": VERSION}})
    if method == "server/discover":
        return response(request_id, {"protocolVersion": PROTOCOLS[0], "serverInfo": {"name": "media-atlas", "version": VERSION}, "capabilities": {"tools": {"listChanged": False}}})
    if method == "tools/list":
        return response(request_id, {"tools": tool_definitions()})
    if method == "tools/call":
        params = message.get("params") or {}
        name, arguments = params.get("name"), params.get("arguments") or {}
        if name not in HANDLERS or not isinstance(arguments, dict):
            return response(request_id, error={"code": -32602, "message": "unknown tool or invalid arguments"})
        try:
            with connect() as database:
                result = HANDLERS[name](database, arguments)
            return response(request_id, {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False, sort_keys=True)}], "structuredContent": result, "isError": False})
        except (ValueError, sqlite3.Error, OSError) as error:
            return response(request_id, {"content": [{"type": "text", "text": str(error)}], "isError": True})
    return response(request_id, error={"code": -32601, "message": "method not found"})


def main() -> int:
    for raw in sys.stdin.buffer:
        if len(raw) > MAX_LINE:
            sys.stdout.write(json.dumps(response(None, error={"code": -32600, "message": "request too large"})) + "\n"); sys.stdout.flush(); continue
        try:
            message = json.loads(raw)
            if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
                raise ValueError("invalid request")
            result = handle(message)
        except (ValueError, json.JSONDecodeError) as error:
            result = response(None, error={"code": -32600, "message": str(error)})
        if result is not None:
            sys.stdout.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
